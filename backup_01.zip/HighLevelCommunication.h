#ifndef HIGH_LEVEL_COMMUNICATION_HEADER_
#define HIGH_LEVEL_COMMUNICATION_HEADER_

#include "Defs.h"
#include "MessageList.h"

int register_id_server(int id_fd, struct sockaddr_in *id_serveraddr, int id_addrlen, char * name, char * ip, int upt, int tpt);
int join(int id_fd, struct sockaddr_in *id_serveraddr, int id_addrlen, char * name, char * ip, int upt, int tpt, int *joined, time_t *prevTime, struct timeval *timeout, int r);
int show_servers();
int show_messages(messageList *ml);

int publish(int fd, char *message, struct sockaddr_in *serveraddr, int addrlen);
int show_last_messages(int fd, struct sockaddr_in *serveraddr, int addrlen, int n);
int get_msgserv_identity(char *buffer, char **ip, int *upt, int *tpt, party con);

#endif