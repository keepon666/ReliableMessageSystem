#include "MessageList.h"

/* contructor and destructor */
void initMessageList(messageList **ml, int maxSize) {
  (*ml) = (messageList *) malloc(sizeof(messageList));

  (*ml)->maxSize = maxSize;
  (*ml)->actualSize = 0;
  (*ml)->head = (messageNode *) NULL;
  (*ml)->tail = (messageNode *) NULL;
}

void destroyMessageList(messageList **ml)
{
  messageNode *prev, *next;

  if((*ml) == (messageList *) NULL)
    return;

  prev = getHeadMessageList(*ml);

  while(prev) {
    next = getNextNodeMessageList(prev);
    deleteNodeMessageList((*ml), prev);
    prev = next;
  }

  free(*ml);

  (*ml) = (messageList *) NULL;
}

/* getters and setters*/
messageNode * getHeadMessageList(messageList *ml) {
  return ml->head;
}

messageNode * getTailMessageList(messageList *ml) {
  return ml->tail;
}

messageNode * getNextNodeMessageList(messageNode *node) {
  if(node == (messageNode *) NULL)
    return node;
  else
    return node->next;
}

messageNode * getPrevNodeMessageList(messageNode *node) {
  if(node == (messageNode *) NULL)
    return node;
  else
    return node->prev;
}

char * getMessageMessageList(messageNode *node) {
  return node->message;
}

int getLogicCounterMessageList(messageNode *node) {
  return node->logicCounter;
}

void insertNodeMessageList(messageList *ml, char *msg, int lc) {
  messageNode *newNode, *prev, *next;

  newNode = (messageNode *) malloc(sizeof(messageNode));
  newNode->message = (char *) malloc((strlen(msg) + 1) * sizeof(char));

  strcpy(newNode->message, msg);
  newNode->logicCounter = lc;

  for(next = getHeadMessageList(ml); (next != (messageNode *) NULL) && (getLogicCounterMessageList(next) > lc); next = getNextNodeMessageList(next));

  newNode->next = next;

  /* insert at the end */
  if(next == (messageNode *) NULL) {
    newNode->prev = getTailMessageList(ml);

    /* the list is not empty */
    if((prev = getTailMessageList(ml)) != (messageNode *) NULL)
      prev->next = newNode;
    else
      ml->head = newNode;

    ml->tail = newNode;
  }
  else {
    newNode->prev = next->prev;
    next->prev = newNode;

    /* insert at the beginning */
    if((prev = newNode->prev) == (messageNode *) NULL)
      ml->head = newNode;
    else
      prev->next = newNode;
  }

  ml->actualSize++;

  deleteExcessMessageList(ml);
}

void deleteNodeMessageList(messageList *ml, messageNode *node) {
  messageNode *prev, *next;

  prev = getPrevNodeMessageList(node);
  next = getNextNodeMessageList(node);

  /* it is not the head */
  if(prev != (messageNode *) NULL)
    prev->next = next;
  else
    ml->head = next;

  /* it is not the tail */
  if(next != (messageNode *) NULL)
    next->prev = prev;
  else
    ml->tail = prev;

  free(node->message);
  free(node);

  ml->actualSize--;
}

/* auxiliar functions */
void deleteExcessMessageList(messageList *ml) {
  while(ml->actualSize > ml->maxSize)
    deleteNodeMessageList(ml, getTailMessageList(ml));
}
