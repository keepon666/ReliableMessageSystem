#include "Defs.h"
#include "LowLevelCommunication.h"
#include "HighLevelCommunication.h"

int main(int argc, char **argv) {
  /* variables for identities' server communication */
  char *siip;
  int sipt = DEFAULT_SIPT;

  /* variables for msgserv communication */
  char *msgs_siip;
  int msgs_sipt; 

  /* variables for udp client for id server */
  int id_fd, id_addrlen;
  struct hostent *id_hostptr;
  struct sockaddr_in id_serveraddr, id_clientaddr;

  /* variables for udp client */
  int fd, addrlen;
  struct hostent *hostptr;
  struct sockaddr_in serveraddr, clientaddr;

  /* auxiliar variables */
  int i, n, quit = 0;
  char buffer[MAX_SIZE_STRING], command[MAX_SIZE_STRING], message[MAX_SIZE_STRING];

  /* set defaults */
  siip = (char *) malloc((strlen(DEFAULT_SIIP) + 1) * sizeof(char));
  strcpy(siip, DEFAULT_SIIP);

  /* take care of arguments */
  for(i = 1; i < argc; i++) {
    if(!strcmp(argv[i], "-i") && (i < argc - 1)) {
      free(siip);
      siip = (char *) malloc((strlen(argv[i + 1]) + 1) * sizeof(char));
      strcpy(siip, argv[i + 1]);
    }
    else if(!strcmp(argv[i], "-p") && (i < argc - 1)) {
      sipt = atoi(argv[i + 1]);
    }
    else {
      fprintf(stderr, "[FATAL] invalid usage.\n");
      exit(-1);
    }

    i++;
  }

  /* ask for servers to identity server */
  if(init_udp(&id_fd, &id_hostptr, siip, sipt, &id_serveraddr, &id_clientaddr, &id_addrlen, client) == -1) {
    fprintf(stderr, "[FATAL] could not initialize udp.\n");
    exit(-1);
  }

  sprintf(buffer, "GET_SERVERS");
  sendto(id_fd, buffer, strlen(buffer) + 1, 0, (struct sockaddr*) &id_serveraddr, id_addrlen);

  for(i = 0; i < MAX_SIZE_STRING; i++)
    buffer[i] = '\0';

  recvfrom(id_fd, buffer, sizeof(buffer), 0, (struct sockaddr*) &id_serveraddr, &id_addrlen);

  if(get_msgserv_identity(buffer, &msgs_siip, &msgs_sipt, NULL, client) == -1) {
    fprintf(stderr, "[FATAL] there's no registered servers\n");
    exit(-1);
  }

  /* initialize udp */
  if(init_udp(&fd, &hostptr, msgs_siip, msgs_sipt, &serveraddr, &clientaddr, &addrlen, client) == -1) {
    fprintf(stderr, "[FATAL] could not initialize udp.\n");
    exit(-1);
  }

  /* main loop */
  while(!quit) {
    do {
      printf("%s > ", argv[0] + 2);
      fflush(stdout);

      fgets(buffer, MAX_SIZE_STRING, stdin);
      sscanf(buffer, "%s", command);
    } while(buffer[0] == '\n');

    if(!strcmp(command, "show_servers")) {
      if(show_servers() != 0)
        printf("[ERROR] could not show servers\n");
    }
    else if(!strcmp(command, "publish")) {
      for(i = 0; ; i++) {
        message[i] = buffer[i + strlen(command) + 1];
        if((buffer[i + strlen(command) + 1] == '\n') || (i == MAX_SIZE_MSG - 1)) {
          message[i] = '\0';
          break;
        }
      }
      
      if(publish(fd, message, &serveraddr, addrlen) != 0)
        printf("[ERROR] could not publish the message\n");
    }
    else if(!strcmp(command, "show_last_messages")) {
      sscanf(buffer, "show_last_messages %d", &n);

      if(show_last_messages(fd, &serveraddr, addrlen, n) != 0)
        printf("[ERROR] could not show messages\n");
    }
    else if(!strcmp(command, "exit"))
      quit = 1;
    else
      printf("[ERROR] invalid command\n");
  }

  /* free memory */
  free(siip);
  free(msgs_siip);
  close(id_fd);
  close(fd);

  exit(0);
}
