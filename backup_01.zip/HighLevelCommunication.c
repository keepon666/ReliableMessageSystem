#include "HighLevelCommunication.h"

/* server functions */
int register_id_server(int id_fd, struct sockaddr_in *id_serveraddr, int id_addrlen, char * name, char * ip, int upt, int tpt) {
  char msgtosend[MAX_SIZE_STRING];
  
  sprintf(msgtosend, "REG %s;%s;%d;%d", name, ip, upt, tpt);
  sendto(id_fd, msgtosend, strlen(msgtosend) + 1, 0, (struct sockaddr*) id_serveraddr, id_addrlen);

  return 0;
}

int join(int id_fd, struct sockaddr_in *id_serveraddr, int id_addrlen, char * name, char * ip, int upt, int tpt, int *joined, time_t *prevTime, struct timeval *timeout, int r) {
  if(register_id_server(id_fd, id_serveraddr, id_addrlen, name, ip, upt, tpt) == -1) {
    return -1;
  }

  (*joined) = 1;
  (*prevTime) = time((time_t *) NULL);
  timeout->tv_sec = r;
  timeout->tv_usec = 0;

  return 0;
}

int show_servers() {
  return 0;
}

int show_messages(messageList *ml) {
  messageNode *node;

  for(node = getHeadMessageList(ml); node != (messageNode *) NULL; node = getNextNodeMessageList(node))
    printf("%s\n", getMessageMessageList(node));

  return 0;
}

/* client functions */
int publish(int fd, char *message, struct sockaddr_in *serveraddr, int addrlen) {
  char msgtosend[MAX_SIZE_STRING];
  
  sprintf(msgtosend, "PUBLISH %s", message);
  sendto(fd, msgtosend, strlen(msgtosend) + 1, 0, (struct sockaddr*) serveraddr, addrlen);

  return 0;
}

int show_last_messages(int fd, struct sockaddr_in *serveraddr, int addrlen, int n) {
  char msgtosend[MAX_SIZE_STRING], buffer[MAX_SIZE_STRING];
  
  sprintf(msgtosend, "GET_MESSAGES %d", n);
  sendto(fd, msgtosend, strlen(msgtosend) + 1, 0, (struct sockaddr*) serveraddr, addrlen);

  recvfrom(fd, buffer, sizeof(buffer), 0, (struct sockaddr*) &serveraddr, &addrlen);

  printf("%s\n", buffer);

  return 0;
}

int get_msgserv_identity(char *buffer, char **ip, int *upt, int *tpt, party con) {
  int i;
  char *seg[3];

  /* get first segment and discard it - includes name */
  strtok(buffer, ";");

  seg[0] = strtok(NULL, ";");
  seg[1] = strtok(NULL, ";");
  seg[2] = strtok(NULL, "\n");

  for(i = 0; i < 3; i++) {
    if(seg[i] == NULL)
      return -1;
  }

  (*ip) = (char *) malloc((strlen(seg[0]) + 1) * sizeof(char));
  strcpy(*ip, seg[0]);

  (*upt) = atoi(seg[1]);
  if(con == server)
    (*tpt) = atoi(seg[2]);

  return 0;
}
