#ifndef SERVER_LIST_HEADER_
#define SERVER_LIST_HEADER_

#include "Defs.h"

typedef struct serverList_ {
  struct serverNode_ *head, *tail;
  int actualSize;
} serverList;

typedef struct serverNode_ {
  struct serverNode_ *prev, *next;
  int fd;
} serverNode;

/* contructor and destructor */
void initServerList(serverList **sl);
void destroyServerList(serverList **sl);

/* getters and setters*/
serverNode * getHeadServerList(serverList *sl);
serverNode * getTailServerList(serverList *sl);
serverNode * getNextNodeServerList(serverNode *node);
serverNode * getPrevNodeServerList(serverNode *node);
int getFileDescriptorServerList(serverNode *node);

void insertNodeServerList(serverList *sl, int fd);
void deleteNodeServerList(serverList *sl, serverNode *node);

#endif
