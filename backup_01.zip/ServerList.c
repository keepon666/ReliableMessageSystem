#include "ServerList.h"

/* contructor and destructor */
void initServerList(serverList **sl) {
  (*sl) = (serverList *) malloc(sizeof(serverList));

  (*sl)->actualSize = 0;
  (*sl)->head = (serverNode *) NULL;
  (*sl)->tail = (serverNode *) NULL;
}

void destroyServerList(serverList **sl)
{
  serverNode *prev, *next;

  if((*sl) == (serverList *) NULL)
    return;

  prev = getHeadServerList(*sl);

  while(prev) {
    next = getNextNodeServerList(prev);
    deleteNodeServerList((*sl), prev);
    prev = next;
  }

  free(*sl);

  (*sl) = (serverList *) NULL;
}

/* getters and setters*/
serverNode * getHeadServerList(serverList *sl) {
  return sl->head;
}

serverNode * getTailServerList(serverList *sl) {
  return sl->tail;
}

serverNode * getNextNodeServerList(serverNode *node) {
  if(node == (serverNode *) NULL)
    return node;
  else
    return node->next;
}

serverNode * getPrevNodeServerList(serverNode *node) {
  if(node == (serverNode *) NULL)
    return node;
  else
    return node->prev;
}

int getFileDescriptorServerList(serverNode *node) {
  return node->fd;
}

void insertNodeServerList(serverList *sl, int fd) {
  serverNode *newNode;

  newNode = (serverNode *) malloc(sizeof(serverNode));
  newNode->fd = fd;

  newNode->prev = getTailServerList(sl);
  newNode->next = (serverNode *) NULL;

  /* the list is empty */
  if(sl->tail == (serverNode *) NULL)
    sl->head = newNode;
  else
    sl->tail->next = newNode;

  sl->tail = newNode;

  sl->actualSize++;
}

void deleteNodeServerList(serverList *sl, serverNode *node) {
  serverNode *prev, *next;

  prev = getPrevNodeServerList(node);
  next = getNextNodeServerList(node);

  /* it is not the head */
  if(prev != (serverNode *) NULL)
    prev->next = next;
  else
    sl->head = next;

  /* it is not the tail */
  if(next != (serverNode *) NULL)
    next->prev = prev;
  else
    sl->tail = prev;

  free(node);

  sl->actualSize--;
}
