#include "Defs.h"
#include "LowLevelCommunication.h"
#include "HighLevelCommunication.h"

#include "MessageList.h"
#include "ServerList.h"

#define DEFAULT_M 200
#define DEFAULT_R 10

int main(int argc, char ** argv) {
  /* main variables */
  char *name = NULL, *ip = NULL, *siip;
  int upt = -1, tpt = -1, sipt = DEFAULT_SIPT, m = DEFAULT_M, r = DEFAULT_R;

  char buffer[MAX_SIZE_STRING], command[MAX_SIZE_STRING];
  int n;

  messageList *ml;
  serverList *sl;
  char message[MAX_SIZE_STRING], command_msg[MAX_SIZE_STRING];
  int joined = 0, lc = 0;

  /* variables for udp client */
  int id_fd, id_addrlen;
  struct hostent *id_hostptr;
  struct sockaddr_in id_serveraddr, id_clientaddr;

  /* variables for udp server */
  int fd, addrlen;
  struct sockaddr_in serveraddr, clientaddr;

  /* variables for tcp client and server
  int fd, newfd;
  struct hostent *hostptr;
  struct sockaddr_in serveraddr, clientaddr;
  int clientlen;*/

  /* multiplexing variables */
  fd_set rfds;
  int maxfd, counter;
  struct timeval timeout;
  time_t prevTime, actualTime, cycleDelay;

  /* auxiliar variables */
  int i, quit = 0;
  messageNode *node;

  /* set defaults */
  siip = (char *) malloc((strlen(DEFAULT_SIIP) + 1) * sizeof(char));
  strcpy(siip, DEFAULT_SIIP);

  /* arguments parsing */
  for(i = 1; i < argc; i++) {
    if(!strcmp(argv[i], "-n") && (i < argc - 1)) {
      name = (char *) malloc((strlen(argv[i + 1]) + 1) * sizeof(char));
      strcpy(name, argv[i + 1]);
    }
    else if(!strcmp(argv[i], "-j") && (i < argc - 1)) {
      ip = (char *) malloc((strlen(argv[i + 1]) + 1) * sizeof(char));
      strcpy(ip, argv[i + 1]);
    }
    else if(!strcmp(argv[i], "-u") && (i < argc - 1)) {
      upt = atoi(argv[i + 1]);
    }
    else if(!strcmp(argv[i], "-t") && (i < argc - 1)) {
      tpt = atoi(argv[i + 1]);
    }
    else if(!strcmp(argv[i], "-i") && (i < argc - 1)) {
      free(siip);
      siip = (char *) malloc((strlen(argv[i + 1]) + 1) * sizeof(char));
      strcpy(siip, argv[i + 1]);
    }
    else if(!strcmp(argv[i], "-p") && (i < argc - 1)) {
      sipt = atoi(argv[i + 1]);
    }
    else if(!strcmp(argv[i], "-m") && (i < argc - 1)) {
      m = atoi(argv[i + 1]);
    }
    else if(!strcmp(argv[i], "-r") && (i < argc - 1)) {
      r = atoi(argv[i + 1]);
    }
    else {
      fprintf(stderr, "[FATAL] invalid usage.\n");
      exit(-1);
    }

    i++;
  }

  if((name == NULL) || (ip == NULL) || (upt == -1) || (tpt == -1)) {
    fprintf(stderr, "[FATAL] invalid usage.\n");
    exit(-1);
  }

  /* initialize udp client */
  if(init_udp(&id_fd, &id_hostptr, siip, DEFAULT_SIPT, &id_serveraddr, &id_clientaddr, &id_addrlen, client) == -1) {
    fprintf(stderr, "[FATAL] could not initialize udp client.\n");
    exit(-1);
  }

  /* initialize udp server */
  if(init_udp(&fd, (struct hostent **) NULL, (char *) NULL, upt, &serveraddr, &clientaddr, &addrlen, server) == -1) {
    fprintf(stderr, "[FATAL] could not initialize udp server.\n");
    exit(-1);
  }

  /* initialize message and server lists */
  initMessageList(&ml, m);
  initServerList(&sl);

  /* establish tcp connections to each of registered server */

  /* just to initialize the shell */
  printf("%s > ", argv[0] + 2);
  fflush(stdout);

  while(!quit) {
    /* it has to be checked if every single server is alive at the moment (drop if cannot reach?) */
    
    /* select to multiplex */
    FD_ZERO(&rfds);
    FD_SET(STDIN_FD, &rfds);
    FD_SET(fd, &rfds);
    maxfd = MAX(STDIN_FD, fd);

    /* counter means the number of descriptors that are active */
    counter = joined ? select(maxfd + 1, &rfds, (fd_set *) NULL, (fd_set *) NULL, &timeout) : select(maxfd + 1, &rfds, (fd_set *) NULL, (fd_set *) NULL, (struct timeval *) NULL);

    if(counter < 0) {
      fprintf(stderr, "[FATAL] select unlocked with negative file descriptor.\n");
      exit(-1);
    }
    else if(counter > 0) {
      if(FD_ISSET(STDIN_FD, &rfds)) {
        fgets(buffer, MAX_SIZE_STRING, stdin);
        sscanf(buffer, "%s", command);

        if(!strcmp(command, "join")) {
          if(join(id_fd, &id_serveraddr, id_addrlen, name, ip, upt, tpt, &joined, &prevTime, &timeout, r) != 0)
            printf("[ERROR] could not join the server\n");
        }
        else if(!strcmp(command, "show_servers")) {
          if(show_servers() != 0)
            printf("[ERROR] could not show servers\n");
        }
        else if(!strcmp(command, "show_messages")) {
          if(show_messages(ml) != 0)
            printf("[ERROR] could not show messages\n");
        }
        else if(!strcmp(command, "exit")) {
          quit = 1;
        }
        else if(command[0] != '\0')
          printf("[ERROR] invalid command\n");

        printf("%s > ", argv[0] + 2);
        fflush(stdout);

        /* clean previous content of command not to be repeated */
        command[0] = '\0';
      }
      else if(FD_ISSET(fd, &rfds)) {
        recvfrom(fd, buffer, sizeof(buffer), 0, (struct sockaddr*) &clientaddr, &addrlen);
        sscanf(buffer, "%s", command_msg);

        if(!strcmp(command_msg, "PUBLISH")) {
          insertNodeMessageList(ml, (buffer + strlen(command_msg) + 1), lc);
        }
        else if(!strcmp(command_msg, "GET_MESSAGES")) {
          sscanf(buffer + strlen(command_msg) + 1, "%d", &n);

          strcpy(message, "MESSAGES\n");
          node = getHeadMessageList(ml);
          for(i = 0; i < n; i++) {
            if(node == (messageNode *) NULL)
              break;

            sprintf(buffer, "%s\n", getMessageMessageList(node));
            strcat(message, buffer);
            node = getNextNodeMessageList(node);
          }

          sendto(fd, message, strlen(message) + 1, 0, (struct sockaddr *) &clientaddr, addrlen);
        }
      }
    }

    if(joined) {
      actualTime = time((time_t *) NULL);

      if((cycleDelay = (int) difftime(actualTime, prevTime)) < r)
        timeout.tv_sec = r - cycleDelay;
      else {
        timeout.tv_sec = r;
        prevTime = time((time_t *) NULL);
        
        if(register_id_server(id_fd, &id_serveraddr, id_addrlen, name, ip, upt, tpt) == -1) {
          fprintf(stderr, "[FATAL] could not register into identity server\n");
          exit(-1);
        }
      }
    }
  }

  /* free memory */
  free(siip);
  free(name);
  free(ip);
  destroyMessageList(&ml);
  close(id_fd);
  close(fd);

  exit(0);
}
