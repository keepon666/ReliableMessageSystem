#ifndef MESSAGE_LIST_HEADER_
#define MESSAGE_LIST_HEADER_

#include "Defs.h"

typedef struct messageList_ {
  struct messageNode_ *head, *tail;
  int maxSize, actualSize;
} messageList;

typedef struct messageNode_ {
  struct messageNode_ *prev, *next;
  char *message;
  int logicCounter;
} messageNode;

/* contructor and destructor */
void initMessageList(messageList **ml, int maxSize);
void destroyMessageList(messageList **ml);

/* getters and setters*/
messageNode * getHeadMessageList(messageList *ml);
messageNode * getTailMessageList(messageList *ml);
messageNode * getNextNodeMessageList(messageNode *node);
messageNode * getPrevNodeMessageList(messageNode *node);
char * getMessageMessageList(messageNode *node);
int getLogicCounterMessageList(messageNode *node);

void insertNodeMessageList(messageList *ml, char *msg, int lc);
void deleteNodeMessageList(messageList *ml, messageNode *node);

/* auxiliar functions */
void deleteExcessMessageList(messageList *ml);

#endif